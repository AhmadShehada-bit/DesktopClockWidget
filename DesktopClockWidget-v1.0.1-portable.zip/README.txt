DesktopClock Widget v1.0.1
=====================================================
A lightweight, customizable Windows desktop clock widget with advanced typography,
custom blocks, dynamic messages, and visual text effects.

Quick Start:
1. Run DesktopClockWidget.exe.
2. Toggle Edit/Drag Mode anytime by pressing: Ctrl + Alt + C
3. Right-click the system tray icon for Settings, Screen Centering, and Exit.
